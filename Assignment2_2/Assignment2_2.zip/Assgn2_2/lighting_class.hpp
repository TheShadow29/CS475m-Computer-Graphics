#ifndef _MYDRAW_CLASS_HPP_
#define _MYDRAW_CLASS_HPP_

//Define all classes like the color class, adding appropriate methods and data members.
//Implementation of the methods go into the corresponding cpp file

//------------------------
//color_t class


//------------------------

#endif
