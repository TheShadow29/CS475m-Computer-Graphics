#include "lighting_class.hpp"


//---------------------
